CREATE TABLE Members (
    member_id BIGINT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);
CREATE TABLE Courses (
    course_id BIGINT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    instructor VARCHAR(100)
);

CREATE TABLE Categories (
    category_id INTEGER PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);


CREATE TABLE CourseCategories (
    id BIGINT PRIMARY KEY,
    course_id INTEGER REFERENCES Courses(course_id),
    category_id INTEGER REFERENCES Categories(category_id)
);


CREATE TABLE Enrollments (
    enrollment_id BIGINT PRIMARY KEY,
    member_id INTEGER REFERENCES Members(member_id),
    course_id INTEGER REFERENCES Courses(course_id),
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Certificates (
    certificate_id INTEGER PRIMARY KEY,
    certificate_code VARCHAR(100) UNIQUE NOT NULL,
    issue_date DATE
);

CREATE TABLE CertificateAssignments (
    assignment_id BIGINT PRIMARY KEY,
    member_id BIGINT REFERENCES Members(member_id),
    certificate_id INTEGER REFERENCES Certificates(certificate_id),
    receive_date DATE
);



CREATE TABLE BlogPosts (
    post_id BIGINT PRIMARY KEY,
    title VARCHAR(255),
    content TEXT,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    author_id INTEGER REFERENCES Members(member_id)
);





